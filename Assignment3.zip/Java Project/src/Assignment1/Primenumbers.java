package Assignment1;

public class Primenumbers {

    public static void main(String[] args) {
        for(int j = 2; j <= 1000; j++){
            boolean checkPrime = prime(j);
            if(checkPrime == true){
                System.out.println(j);
            }
        }
    }

    public static boolean prime(int a){
        boolean flag = true;
        int i = 2;
        while(i < a){
            if(a % i == 0){
                flag = false;
                break;
            }
            i++;
        }
        return flag;
    }

}



