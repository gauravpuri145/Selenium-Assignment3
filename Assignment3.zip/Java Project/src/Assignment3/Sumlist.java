package Assignment3;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class Sumlist {
    public static void main(String[] args) {
        List<Integer> l4 = new ArrayList<>();
        l4 = Arrays.asList(10, 20, 30, 40, 50);
        int sum = 0;
        Iterator<Integer> lstitr = l4.iterator();
        while(lstitr.hasNext()){
            int lstelement = lstitr.next();
            sum = sum + lstelement;

        }
        System.out.println(sum);

    }
}
