package Assignment3;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Listforeachloop {

    public static void main(String[] args) {
        List<Integer> l2 = new ArrayList<>();
        l2 = Arrays.asList(10,20,30,40,50);

        for(int lst : l2){
            System.out.println(lst);
        }
    }
}
