package Assignment3;

import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;

public class Listoperations {


    public static void main(String[] args) {
        List<Integer> l1=new ArrayList<>(Arrays.asList(33,44,55,66,77,88));


        //Remove second element from list using index
        System.out.println(l1.remove(1));
        System.out.println(l1);

        //Remove second element from list using value
        System.out.println(l1.remove(Integer.valueOf(55)));
        System.out.println(l1);

        //Add 90 at index 3
        l1.add(2,90);
        System.out.println(l1);

        //Get the length of list
        System.out.println(l1.size());

        //Print all values from list using any values
        System.out.println(l1);

        //Convert List into array.
        int[] arr = new int[l1.size()];
        for (int i = 0; i < l1.size(); i++) {
            arr[i] = l1.get(i);
        }
        System.out.println("Array is " + Arrays.toString(arr));
    }


}
